export const PURGE_AUTH = "logOut";
export const SET_AUTH = "setUser";
export const SET_USER = "setUser";
export const SET_USERS = "setUsers";
export const SET_REPASS = "setRepass";
export const SET_REPAS = "setRepas";
export const SET_CATEGORIES = "setCategories";
export const SET_CATEGORY = "setCategory";