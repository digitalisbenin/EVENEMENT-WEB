
export const LOGIN = "login";
export const LOGOUT = "logout";
export const REGISTER = "register";
export const UPDATE_USER = "updateUser";

export const FETCH_REPAS = "fetchRepas";
export const REPAS_ADD = "addRepas";
export const REPAS_DELETE = "deleteRepas";
export const REPAS_EDIT = "editRepas";
export const REPAS_RESET_STATE = "resetRepasState";
export const FETCH_REPASS = "fetchRepass";
export const FETCH_USER = "fetchUser";
export const FETCH_USERS = "fetchUsers";
export const USER_ADD = "addUser";
export const USER_DELETE = "deleteUser";
export const USER_EDIT = "editUser";

export const FETCH_CATEGORIES = "fetchCategories";
export const FETCH_ONE_FETCH_CATEGORY = "fetchCategory";

